import React from 'react';

import AdminPanel from '../../admin/components/AdminPanel';
import Gallery from '../../admin/components/Gallery';

const blog = () => {
  return (
    <AdminPanel>
      <Gallery></Gallery>
    </AdminPanel>
  );
};

export default blog;
