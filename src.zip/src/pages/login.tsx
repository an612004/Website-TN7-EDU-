import React from 'react';

import Login from '../admin/components/Login';

const login = () => {
  return <Login></Login>;
};

export default login;
